# DeathSMP modification notice

DeathSMP is a customized modification of the Minara 2.0.0 source provided in the original project archive. The original MIT license and copyright notice are retained in `LICENSE`.

This customization changes product branding, the executable/package name, persistent data directory names, browser storage keys, UI color palette, and adds automatic backup scheduling with five-backup retention.
