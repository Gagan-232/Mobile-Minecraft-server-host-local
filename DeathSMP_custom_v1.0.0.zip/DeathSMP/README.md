<p align="center">
  <img src="assets/logo.png" alt="DeathSMP" width="860" />
</p>

<h1 align="center">DeathSMP</h1>
<p align="center"><strong>Version 1.0.0</strong></p>
<p align="center">
  A customized Rust-powered control panel for managing
  <strong>Minecraft Bedrock Dedicated Server</strong> instances on Android using Termux.
</p>

<p align="center">
  <img src="https://img.shields.io/badge/status-customized-991b1b?style=for-the-badge" alt="Status Customized" />
  <img src="https://img.shields.io/badge/platform-Android%20(Termux)-1f2937?style=for-the-badge" alt="Platform" />
  <img src="https://img.shields.io/badge/Minecraft-Bedrock%20Server-16a34a?style=for-the-badge" alt="Minecraft Bedrock Server" />
  <img src="https://img.shields.io/badge/license-MIT-0b1220?style=for-the-badge" alt="MIT" />
</p>

---

## What this build changes

DeathSMP is a customized build derived from the uploaded Minara 2.0.0 source. The first customization pass changes the product branding, binary/data names, browser storage keys, and UI palette while retaining the existing server-management functionality.

### Current features inherited and retained

- Server lifecycle control: start, stop, status
- Multi-instance management
- Live console streaming and command input
- CPU, RAM, disk, load and uptime monitoring
- Device information integration with Asmo
- File manager: upload, edit, create folders, download and delete
- `server.properties` editor
- Backup create, restore and delete
- Backup identity / lineage checks
- ARM64-oriented bionilux / Box64 launch workflow

### DeathSMP backup policy

- Automatic backup every 30 minutes after startup
- Keeps the newest 5 successful backups per instance
- Older backups are pruned only after a new backup completes successfully
- Manual backups use the same 5-backup retention rule

> Backup implementation copies the instance directory using the same file-copy model as the original backup feature. A live, actively-writing world is not an atomic filesystem snapshot.

## Build

Requires a Rust toolchain and the dependencies listed in `Cargo.toml`.

```bash
cargo build --release
```

The resulting binary is named `deathsmp`.

## Run on Termux

```bash
./target/release/deathsmp
```

Development mode is available with `-d`:

```bash
./target/release/deathsmp -d
```

The panel listens on `0.0.0.0:7777`.

## Data layout

DeathSMP stores persistent data under:

```text
~/.local/share/deathsmp/
├── instances/
└── backups/
```

## Attribution and license

This repository is a customized modification of the uploaded Minara source. The original MIT license and copyright notice are retained in `LICENSE`. See `NOTICE.md` for the modification note.
