# DeathSMP Changelog

## 1.0.0

- Rebranded the control panel from Minara to DeathSMP.
- Renamed the Rust package and binary to `deathsmp`.
- Moved persistent data storage to `~/.local/share/deathsmp`.
- Renamed the per-instance identity marker to `.deathsmp_instance_id`.
- Switched the UI accent palette to a dark red DeathSMP theme.
- Added automatic backups every 30 minutes.
- Added retention of the newest 5 successful backups per instance.
- Manual backups now use the same 5-backup retention rule.
